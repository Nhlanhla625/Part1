﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace RecipeApplication
{
    class Recipe
    {
        private string[] ingredients;
        private string[] steps;
        private string[] unit;
        private double[] quantity;

        public Recipe()
        {
            ingredients = new string[0];
            steps = new string[0];
            unit = new string[0];
            quantity = new double[0];
        }
        public void EnterDetails()
        {
            Console.WriteLine("=========WELCOME TO OUR RECIPE APPLICATION PART 1=========");
            Console.WriteLine("Enter the number of ingredients: ");
            int NumberOfIngredients = Convert.ToInt32(Console.ReadLine());

            ingredients = new string[NumberOfIngredients];
            steps = new string[NumberOfIngredients];
            unit = new string[NumberOfIngredients];
            quantity = new double[NumberOfIngredients];

            for(int b = 0; b < NumberOfIngredients; b++)
            {
                Console.WriteLine("----------------------------------------------");
                    Console.WriteLine($"Enter details for ingredient #{b + 1}:");

                    Console.Write("Enter the name of the ingredient " + (b + 1) + ": ");
                    string name = Console.ReadLine();

                    Console.Write("Enter the quantity " + (b + 1) + ": ");
                    double quantity = double.Parse(Console.ReadLine());

                    Console.Write("Enter the unit of measurement " + (b + 1) + ": ");
                    string unit = Console.ReadLine();

                Console.WriteLine("-----------------------------------------------");
                
            }
                //Enter the number of steps:
                Console.Write("Enter the number of steps: ");
                int NumberOfSteps = int.Parse(Console.ReadLine());
                steps = new string[NumberOfSteps];
                int i;
                for(i = 0; i < NumberOfSteps; i++)
                {
                    Console.Write("Enter step ", i + 1 + ": ");
                    steps[i] = Console.ReadLine();          
                }
            }
             public void DisplayRecipe()
            {
            //Display the ingredients and quantites
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Ingredients:");
                for(int i = 0; i < ingredients.Length; i++)
                {
                    Console.WriteLine($"-{quantity[i]} {unit[i]} of {ingredients[i]}");            
                }

            //Display steps
            Console.WriteLine("-----------------------------------------------");
            Console.WriteLine("Steps: ");
                for(int i = 0; i < steps.Length; i++)
                {
                    Console.WriteLine($"-{steps[i]}");               
                }
            }
            public void ScaleRecipe(double factor)
            {
                //Scale code
                for(int i = 0; i < quantity.Length; i++)
                {
                    quantity[i] *= factor;
                }
            }
            public void ResetQuantity()
            {
            Console.WriteLine("-----------------------------------------------");
            for (int i = 0; i < quantity.Length; i++)
                {              
                quantity[i] /= 2;
                }
            }
            public void ClearRecipe()
            {
                //Empty arrays
                ingredients = new string[0];
                steps = new string[0];
                unit = new string[0];
                quantity = new double[0];
            }
        }
        class Program
        {
            static void Main(string[] args)
            {
            Recipe recipe = new Recipe();
                while (true)
                {
                    Console.WriteLine("Enter '1' to fill the details of recipe: ");
                    Console.WriteLine("Enter '2' to display recipe: ");
                    Console.WriteLine("Enter '3' to scale recipe: ");
                    Console.WriteLine("Enter '4' to reset quantities: ");
                    Console.WriteLine("Enter '5' to clear the recipe: ");
                    Console.WriteLine("Enter '6' Exit: ");

                    string choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "1":
                            recipe.EnterDetails();
                            break;
                        case "2":
                            recipe.DisplayRecipe();
                            break;
                        case "3":
                            Console.WriteLine("Enter the scaling factor (0.5, 2, or 3): ");
                            double factor = double.Parse(Console.ReadLine());
                            recipe.ScaleRecipe(factor);
                            break;
                        case "4":
                            recipe.ResetQuantity();
                            break;
                        case "5":
                            recipe.ClearRecipe();
                            break;
                        case "6":
                            Console.WriteLine("Leaving the program...");
                            return;
                        default:
                            Console.WriteLine("Invalid selection, please validate your choice.");
                            break;

                    }
                }    
            }
        }
    }
