﻿// See https://aka.ms/new-console-template for more information
public class Ingredient
{
    public string Name;
    public double Quantity;
    public string Unit;
    public double OriginalQuantity;

    public Ingredient()
    {
    }

    public Ingredient(string name, double quantity, string unit, double OriginalQuantity)
    {
        Name = name;
        Quantity = quantity;
        Unit = unit;
        OriginalQuantity = quantity;
    }
}