﻿// See https://aka.ms/new-console-template for more information
namespace RecipeManger
{
    internal class Recipe
    {
        public Recipe()
        {
        }
    }
}